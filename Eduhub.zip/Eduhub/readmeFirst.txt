Steps to run this Project run this commands 

-> cd Eduhub
->pip install -r requirements.txt
->python manage.py migrate
->python manage.py runserver
 this will start the server "http://127.0.0.1:8000/" copy this path and paste into browser
 